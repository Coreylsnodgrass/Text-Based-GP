//public class Npc 
    

